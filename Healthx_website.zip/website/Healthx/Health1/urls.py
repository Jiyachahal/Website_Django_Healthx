from django.contrib import admin
from django.urls import path
from Health1 import views 

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.Home,name='home'), 
    path('bmicalculator/', views.bmi_calculator,name='bmicalculator'),
    path('bmrcalculator/', views.bmr_calculator,name='bmrcalculator'),
    path('caloriecalculator/', views.calorie_calculator,name='caloriecalculator'),
    path('contact/', views.contact,name='contact'),
   



    
]
