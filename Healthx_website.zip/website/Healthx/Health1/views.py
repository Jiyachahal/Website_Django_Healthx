from django.shortcuts import render, HttpResponse

from datetime import datetime
from Health1.models import Contact
from django.contrib import messages 

def Home(request):
    return render(request, 'Home.html')

def bmi_calculator(request):
    bmi = None  # Initialize BMI
    category = "Invalid input"  # Default category

    if request.method == "POST":
        print("✅ Received POST request!")
        print(request.POST)  # Debugging
        
        # Get weight and height inputs
        weight = request.POST.get("weight")
        weight_unit = request.POST.get("weightUnit")
        height_unit = request.POST.get("heightUnit")
        
        height_cm = None  # Initialize height in cm

        # Convert weight to kg if entered in lbs
        if weight:
            try:
                weight = float(weight)
                if weight_unit == "lbs":
                    weight = round(weight * 0.453592, 2)  # Convert lbs to kg
            except ValueError:
                weight = None  # Invalid input

        # Handle height in cm
        if height_unit == "cm":
            height_cm = request.POST.get("height")
            if height_cm:
                try:
                    height_cm = float(height_cm)
                except ValueError:
                    height_cm = None  # Invalid input

        # Handle height in feet & inches
        elif height_unit == "ft":
            feet = request.POST.get("heightFeet")
            inches = request.POST.get("heightInches")

            if feet and inches:
                try:
                    feet = float(feet)
                    inches = float(inches)
                    height_cm = round((feet * 30.48) + (inches * 2.54), 2)  # Convert ft & in to cm
                except ValueError:
                    height_cm = None  # Invalid input

        # Calculate BMI if valid inputs exist
        if height_cm and weight:
            height_m = height_cm / 100  # Convert cm to meters
            bmi = round(weight / (height_m ** 2), 2)

        # Determine BMI category
        if bmi is not None:
            if bmi < 16:
                category = "Severe Thinness"
            elif 16 <= bmi < 17:
                category = "Moderate Thinness"
            elif 17 <= bmi < 18.5:
                category = "Mild Thinness"
            elif 18.5 <= bmi < 25:
                category = "Normal"
            elif 25 <= bmi < 30:
                category = "Overweight"
            elif 30 <= bmi < 35:
                category = "Obese Class I"
            elif 35 <= bmi < 40:
                category = "Obese Class II"
            else:
                category = "Obese Class III"

        print(f"Calculated BMI: {bmi}, Category: {category}")  # Debugging line

    return render(request, "bmi_calculator.html", {"bmi": bmi, "category": category})

def bmr_calculator(request):
    if request.method == 'POST':
        gender = request.POST.get('gender')
        age = int(request.POST.get('age'))
        weight = float(request.POST.get('weight'))
        weight_unit = request.POST.get('weight_unit')
        height_unit = request.POST.get('height_unit')

        # Convert weight to kg if in lbs
        if weight_unit == 'lbs':
            weight = weight * 0.453592

        # Convert height to cm
        if height_unit == 'cm':
            height = float(request.POST.get('height_cm'))
        else:
            feet = int(request.POST.get('height_ft') or 0)
            inches = int(request.POST.get('height_in') or 0)
            height = (feet * 12 + inches) * 2.54  # total inches to cm

        # Calculate BMR using Mifflin-St Jeor Equation
        if gender == 'male':
            bmr = 10 * weight + 6.25 * height - 5 * age + 5
        else:
            bmr = 10 * weight + 6.25 * height - 5 * age - 161

        return render(request, 'bmr_calculator.html', {'bmr': round(bmr, 2)})

    return render(request, 'bmr_calculator.html')

def calorie_calculator(request):
    return render(request, 'calorie_calculator.html')

def contact (request):
    if request.method=='POST':
        name=request.POST.get('name')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        desc=request.POST.get('desc')
        contact_entry=contact(name=name , email=email, phone= phone, desc=desc , date=datetime.today())
        contact_entry.save()
        messages.success(request, "Your message has been sent!")
    return render(request,'contact.html')
